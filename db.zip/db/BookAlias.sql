create table BookAliases
(
BookID int,Alias text
);

truncate table BookAliases;
load data local infile '/Users/cg/Documents/Personal/MetaV/CSV/BookAliases.csv' into table BookAliases fields terminated by ','
enclosed by '"'
lines terminated by '\n'
(BookId, Alias)
