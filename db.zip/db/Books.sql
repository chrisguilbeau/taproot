create table Books
(
BookID int primary key,BookName text,NumOfChapters int
);

truncate table Books;
load data local infile '/Users/cg/Documents/Personal/MetaV/CSV/Books.csv' into table Books fields terminated by ','
enclosed by '"'
lines terminated by '\n'
(BookId, BookName, NumOfChapters)
