create table MainIndex
(
	BookID int not null,
	Chapter int not null,
	ParaID int not null,
	SentID int not null,
	VerseID int not null,
	VerseNum int not null,
	VersePos int not null,
	WordID int not null primary key,
	Word text not null,
	Punc text,
	Italic boolean not null,
	cParen boolean not null,
	oParen boolean not null,
	PlaceID int not null,
	Syllables int,
	YearNum int,
	PersonID int not null
);
truncate table MainIndex;
load data local infile '/Users/cg/Documents/Personal/MetaV/CSV/MainIndex.csv' into table MainIndex fields terminated by ','
enclosed by '"'
lines terminated by '\n'
(BookID,Chapter,ParaID,SentID,VerseID,VerseNum,VersePos,WordID,Word,Punc,Italic,cParen,oParen,PlaceID,Syllables,YearNum,PersonID)
