create table Strongs
(
StrongsID varchar(10) primary key,
lemma text,
xlit text,
pronounce text,
description text,
PartOfSpeech text,
Language text
);

truncate table Strongs;
load data local infile '/Users/cg/Documents/Personal/MetaV/CSV/Strongs.csv' into table Strongs fields terminated by ','
enclosed by '"'
lines terminated by '\n'
(StrongsID,lemma,xlit,pronounce,description,PartOfSpeech,Language);
select * from Strongs

