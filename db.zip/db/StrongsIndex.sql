create table StrongsIndex
(
WordId int,
StrongsId varchar(10)
);

truncate table StrongsIndex;
load data local infile '/Users/cg/Documents/Personal/MetaV/CSV/StrongsIndex.csv' into table StrongsIndex fields terminated by ','
enclosed by '"'
lines terminated by '\n'
(WordId, StrongsId)
