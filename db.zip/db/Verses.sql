create table Verses
(
VerseID int primary key,BookID int,Chapter int,VerseNum int,VerseText text

);

truncate table Verses;
load data local infile '/Users/cg/Documents/Personal/MetaV/CSV/Verses.csv' into table Verses fields terminated by ','
enclosed by '"'
lines terminated by '\n'
(VerseID,BookID,Chapter,VerseNum,VerseText
)
