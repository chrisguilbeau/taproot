create table WordDistinctLower
(
Word varchar(255) primary key
);
truncate table WordDistinctLower;
insert WordDistinctLower
select distinct lower(Word) from MainIndex m
join strongsindex s
on s.wordId = m.wordId
order by lower(Word);

select * from WordDistinctLower
where word like 'th%'